function [seq] = builder(cfg)
% Build audio sequence

% adjust tones length fn beat fq
tbuf  = cfg.tbuf/cfg.beat;
ttone = cfg.ttone; % cfg.ttone/cfg.beat;
dt    = cfg.dt;    % cfg.dt/cfg.beat;

% length sequence: fixed portion + random extra ([0-n]s)
tbeat = 1/cfg.beat;
ntar = cfg.ntar; mutime = tbeat*(ntar);
while mutime < cfg.ndur+rand*cfg.ndur 
    ntar = ntar +1; mutime = tbeat*(ntar);
end

% position of ref & tar tones
iref = 0:cfg.nref-1;
itar = (0:ntar-1)+cfg.nref;
iall = [iref, itar]*tbeat;

% position of dis tones (new version)
for i0 = 1:ntar*cfg.ndis % total nb of distractors
    while true
        idis = (rand*ntar+cfg.nref-0.5)*tbeat;
        temp = true;
        for j0 = 1:length(iall)
            if iall(j0)-tbuf-ttone < idis && idis < iall(j0)+ttone+tbuf
            temp = false; break
            end
        end
        if temp, break, end
    end
    iall = [iall, idis];
end

% deviant tone position
ialls = sort(iall);
if (cfg.mu == +1 && ialls(end) == itar(end)*tbeat) ...
        ||  (cfg.mu == -1 && ialls(end) ~= itar(end)*tbeat) % ok
elseif cfg.mu == +1 && ialls(end) ~= itar(end)*tbeat % add last target
    iall = [iall, (ntar+cfg.nref)*tbeat];
elseif cfg.mu == -1 && ialls(end) == itar(end)*tbeat % add last distractor
    iall = [iall, ialls(end)+ttone+tbuf+rand/2*tbeat]; % max: half-beat       
end
clear ialls iref itar idis tbuf
iall = round(iall*cfg.fsample);
iall = sort(iall);

% build sequence
n = round(tbeat*cfg.fsample)*(cfg.nref+ntar);
dur = round(ttone*cfg.fsample);
dn = round(dt*cfg.fsample);
ds = dn/sqrt(-2*log(10^(-cfg.db/20)));
dx = exp(-([1:dn]-dn).^2/(2*ds^2));
x = zeros(1,n);
for i0 = 1:length(iall)-1
    x(iall(i0)+[1:dur]) = sin(2*pi*cfg.fref*[1:dur]/cfg.fsample);
    di = iall(i0)+[1:dn];
    x(di) = x(di).*dx;
    di = iall(i0)-[1:dn]+dur+1;
    x(di) = x(di).*dx;
end
ftar = round(2.^(log2(cfg.fref)+cfg.ftar));
i0 = length(iall);
    x(iall(i0)+[1:dur]) = sin(2*pi*ftar*[1:dur]/cfg.fsample);
    di = iall(i0)+[1:dn];
    x(di) = x(di).*dx;
    di = iall(i0)-[1:dn]+dur+1;
    x(di) = x(di).*dx;

% cut extra silence after target (cfg.mu = -1 case)
x = x(1:(iall(end)+dur));
clear n dur dn ds dx di ftar i0

% pre & post silence period
npre  = round(cfg.tpre*cfg.fsample);
npost = round(cfg.tpost*cfg.fsample);
x = [zeros(1,npre), x, zeros(1,npost)];
x = x *cfg.vol;

% output matrix
seq      = [];
seq.cfg  = cfg;
seq.x    = x;
seq.iall = iall+npre; % sorted fn time [ref, tar, dis]

end