function [cfg, str, trn] = header

% AUDIO SEQUENCE PARAMETERS
% Basic parameters
cfg         = [];
cfg.fsample = 44100;      % sampling frequency (Hz) [do not change!]44100
cfg.vol     = 0.2;        % [default = 0.2]
cfg.db      = 40;         % dampening attenuation (dB) [do not change!]
cfg.dt      = 2.5e-3;     % dampening length (s)
cfg.ttone   = 22.5e-3;    % tone length (s)
cfg.tbuf    = 090e-3;     % min isi btwn two tones (s) [default: 10% of beat period; ie 100ms @1hz beat]   090e-3
cfg.tpre    = 333e-3;     % pre-roll length (s)  [default: 333 ms]
cfg.tpost   = 050e-3;     % post-roll length (s) after last picth deviant [default: 0 ms]
cfg.ppx     = 40;         % pixel per degre of visual angle [default: 80]
 
% Tasks parameters
cfg.nref    = 3;        % number of reference tones [default: 3|4]
cfg.fref    = 660;      % reference frequency (Hz) [default: 1320 Hz]
cfg.ftar    = 3/12;     % pitch deviation [default: 3 semitones]
cfg.fbeat   = round(2.^(log2(1.5)+(-1.45:.4:1.45)), 2); % 8 values
cfg.flabel  = {'1','2','3','4','5','6','7','8'};    
cfg.nbeat   = length(cfg.fbeat);
cfg.beat    = [];       % beat frequency (Hz) [default: 1.5 Hz]
cfg.ndis0   = 0.3;      % n distractor / beat [default: .3]
cfg.ndis    = [];       % nb distractor tones: difficulty level
cfg.mu      = [];       % target on or off beat [+1|-1]
cfg.ntar    = 4;        % min number of cycles before target [default: 4]
cfg.ndur    = 2;        % min duration of sequence [default: 2s]
cfg.condtype= {'Tracking', 'Listen'}; % 1-tracking/2-Listen
cfg.cond    = [];       % condition (tapping/listen)
cfg.ntrial  = 20;       % [default: 20 (multiple of 2)]
cfg.nbloc   = 16;       % [default: 8 (multiple of nbeat & ncond)]

% Continuous staircase parameter
str         = [];
str.nbaccu  = 6;        % update mu every n trials [default: 6]
str.ptarget = 0.75;     % target proportion correct [default: 0.75]
str.incsize = 0.7;      % size if increment [default: 0.5]
str.avgstr  = 3;        % final difficulty based on last n-trials/x [default: 33%]
str.beat    = 2;        % staircase beat frequency (Hz) [default: 2 Hz]
str.nerror  = 79;       % number of trials before staircase ends [default: 80]
str.ndismax = 3;        % maximum n distractor / beat [default: 3]

% Training parameters
trn.maxresp = [repmat(3, 1,4) ones(1,cfg.nbeat)];  % consecutive correct responses [default: 4]
trn.ndis0   = [0 .2 .3 .4 repmat(.3, 1,cfg.nbeat)];% n distractor / beat
trn.fbeat   = [repmat(2.27, 1,4) cfg.fbeat];       % beat frequency (Hz)
   
end
