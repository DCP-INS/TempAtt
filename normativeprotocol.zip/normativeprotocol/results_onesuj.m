%% Analysis: One observer
clear
clc
close all

% define data
SUJETS = {'s01','s02'}; % ...
isuj = 1;
subject = SUJETS{isuj};

% Paths
origDir = '/Users/...';
addpath(genpath(origDir)); cd(origDir)

% load data
ifile = dir(['data/TA18_' subject '_1*.mat']);
load([ 'data/' ifile(end).name])

% varnames
varname = {'Proportion Correct', 'Mean RT (ms)', 'Hit Inverse Efficiency (sec)'}; 
yval = [.4 1; 0 2; 0 3];
beats = cfg.fbeat(end:-1:1);

% ---
% extract data: one condition (listen/tracking)
out = [];
for ibeat = 1:length(beats)
    y = X.beat == beats(ibeat);
    out{1}(1,ibeat,:) = X.iscor(y);
    out{2}(1,ibeat,:) = X.rt(y);
end
% % extract data: listen & tapping
% out = [];
% for itapp = 1:2
%     x = X.cond == itapp;
%     for ibeat = 1:length(beats)
%         y = X.beat == beats(ibeat);
%         out{1}(itapp,ibeat,:) = X.iscor(x&y);
%         out{2}(itapp,ibeat,:) = X.rt(x&y);
%     end
% end

% nan rt > 2sd
rtmax = 2*std(out{2}(:));
out{2}(out{2}>rtmax) = NaN; % rt outliers (+2sd)
out{1}(out{2}>rtmax) = NaN;
% avg trials
out{1} = nanmean(out{1}, 3);
out{2} = nanmean(out{2}, 3);
clear x y rtmax

% ---
% figure
figure; set(gcf,'color','w'); colormap([.5 .5 .5; 1 1 1])

% Difficulty
    subplot(2,2, 1)
    bar(cfg.ndis)
    set(gca, 'FontSize', 13, 'FontName', 'Arial')
    ylim( [0, 3] )
    ylabel( 'Difficulty (nb dis/beat)' )
    xlim( [.0, 2] )
    set(gca,'XTick', [] )
    set(gca,'Layer','top','Box','off','TickLength',[.01 .01])
    
% performance fn beat
for i0 = 1 %:length(out)    
    subplot(2,2, i0+1); hold on
    plot(1:cfg.nbeat, out{i0}(1,:), '--.', 'markersize', 20, 'Color','k')
    % plot(1:cfg.nbeat, out{i0}(2,:), '--.', 'markersize', 20, 'Color', [.5 .5 .5])    
    set(gca, 'FontSize', 13, 'FontName', 'Arial')
    ylim( yval(i0,:) )
    ylabel( varname{i0} )
    xlim( [.5, 8.5] )
    set(gca,'XTick',1:cfg.nbeat )
    set(gca,'XTickLabel', round(beats,1) )
    xlabel( 'Beat frequency (Hz)' )
    set(gca,'Layer','top','Box','off','TickLength',[.01 .01])
end
% legend( cfg.condtype )

