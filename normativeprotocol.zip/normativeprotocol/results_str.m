function results_str(Y, str)
    Y = RefreshStaircase(Y);

dif = 1./Y.x; %! percentage of distractor (cf staircase.m)
% Figure 1: staircase: evolution of difficulty across experiment
figure; set(gcf,'color','w'); colormap([.5 .5 .5; 1 1 1])
    plot(1:str.nbaccu:Y.i, dif(1:str.nbaccu:Y.i), 'k', 'Linewidth', 2)
%     ylim([min(dif), max(dif)])
    xlim([1, Y.i])
    set(gca,'XTick', 1:str.nbaccu:Y.i)

% Estimated difficulty
n = round(Y.i/str.avgstr); % estimate with last n trial
   thd = GetStaircaseThreshold(GetStaircaseResults(Y), n);
   thd.xthres = 1/thd.xthres; %!
% fprintf('Average performance: %0.2g\n', mean(thd.p(thd.istp)) )
% fprintf('Average difficulty : %0.2g\n', mean(thd.x(thd.istp)) ) %!
 
xx = sprintf('For a threshold of %0.2g \nThe expected accuracy (Hit-FA) \nis %0.2g percent', ...
    thd.xthres, 1e2*thd.pthres);
mTextBox = uicontrol('style','text');
    set(mTextBox,'String',xx)
    set(mTextBox,'Position', [325 350 250 50])
    set(mTextBox, 'FontSize', 13, 'FontName', 'Arial')
    set(mTextBox,'BackgroundColor','w')
    
% title( subject )
set(gca, 'FontSize', 13, 'FontName', 'Arial')
set(gca,'Layer','top','Box','off','TickLength',[.01 .01])
xlabel('Trials')
% ylabel('Inverse Difficulty')
ylabel('Percentage of distractors (/targets)')
      
end



