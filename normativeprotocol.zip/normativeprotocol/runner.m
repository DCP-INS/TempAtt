%% TempAtt
clear; clc; close all
% Paths
origDir = '/Users/...'; %!
addpath(genpath('/Applications/Psychtoolbox')) %!
addpath(genpath(origDir)); cd(origDir)

[cfg, str, trn] = header;
subject = input('Observer namecode = ', 's');   % name (e.g. s01)
cfg.cond  = input('Condition type (1/2/3) = '); % Tracking/Listen (see thexp.m)

%% ------------------------------------------------------------------------
%% Training (5 min) & Staircase (8 min)
filename = sprintf('TA18_%s_str_%s.mat', subject, datestr(now,'yymmdd_HHMM'));
tic; training(cfg, trn);
cd(origDir);[cfg.ndis, Y] = staircase(filename, cfg, str);
sprintf('elapsed time: %2.1f min', toc/60)

%% Staircase visualisation: 
% should go UP (more distractors/beat)
% ! ndis must be <3
ifile = dir(['data/TA18_' subject '_str*.mat']);
load(['data/' ifile(end).name]) % if multiple versions
results_str(Y, str)

%% Main experiment (53 min)
cfg.ndis = input('Difficulty level = ');
filename = sprintf('TA18_%s_%s_%s.mat', subject, cfg.condtype{cfg.cond}, datestr(now,'yymmdd_HHMM'));
tic; cd(origDir); thexp(filename, cfg);
sprintf('elapsed time: %2.1f min', toc/60)

