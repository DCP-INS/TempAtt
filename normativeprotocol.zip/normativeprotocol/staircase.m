function [mu, Y] = staircase(filename, cfg, str)

% Buttons
KbName('UnifyKeyNames');
keywait = KbName('space'); % press space to start bloc
keyquit = KbName('ESCAPE'); % press ESCAPE at response time to quit
keyresp = KbName({'DownArrow','UpArrow'}); % press DOWN for <f(REF) and UP for >f(REF)
mapresp = [-1,+1];
video     = [];
video.i   = max(Screen('Screens'));
video.res = Screen('Resolution',video.i);

% EXPERIMENT LOOP
PsychJavaTrouble;
try  
    % initiate video
    HideCursor;
    FlushEvents;
    ListenChar(2);
    % Screen('Preference','SkipSyncTests',1); %!     
    Screen('Preference','VisualDebuglevel',3);
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask','General','UseFastOffscreenWindows');
    PsychImaging('AddTask','General','NormalizedHighresColorRange');
    video.h = PsychImaging('OpenWindow',video.i,0);
    [video.x,video.y] = Screen('WindowSize',video.h);
    video.ifi = Screen('GetFlipInterval',video.h,100,50e-6,10);
    Screen('BlendFunction',video.h,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    Priority(MaxPriority(video.h));
    Screen('ColorRange',video.h,1);
    Screen('TextFont',video.h,'Helvetica');
    Screen('TextSize',video.h,round(0.5*cfg.ppx));
    Screen('FillRect',video.h,0.5); % background luminance
    
    % initiate sound
    InitializePsychSound(1);
    devices = PsychPortAudio('GetDevices');
    for i0 = 1:length(devices)
        if devices(i0).NrInputChannels == 0 && devices(i0).NrOutputChannels == 2
            break
        end
    end
    audio = [];
    audio.i = devices(i0).DeviceIndex;
    audio.freq = devices(i0).DefaultSampleRate;
    audio.h = PsychPortAudio('Open',audio.i,1,1,audio.freq,2);
    PsychPortAudio('RunMode',audio.h,1);
    
    txt = (['Merci \n'...
        'Vous allez maintenant pratiquer � diff�rents niveaux de difficult�.' ]); PsychVis    
    txt = (['Information importante: vous NE DEVEZ PAS battre le rythme en mesure. '...
        ' Vous ne devez pas bouger, seulement imaginer le rythme dans votre t�te '...
        'pour d�tecter si le son deviant final tombe EN rythme ou HORS du rythme.']); PsychVis
    txt = (['N''oubliez pas de fixer la croix au milieu de l''�cran lors de la pr�sentation des sons. '...
        'Cela vous permettra de vous concentrer sur la s�quence.']); PsychVis
    txt = ('Pr�t(e)?'); PsychVis
     
% xp parameters    
Y = CreateStaircase(str.ptarget, 1/cfg.ndis0, str.incsize, str.nbaccu);
aborted = false;
counter = 0;
cfg.beat= str.beat;

while true
    counter = counter + 1;
    % staircase procedure for difficulty (mu)
    cfg.ndis = max(1/GetStaircaseVariable(Y), cfg.ndis0); %! set a MIN diff!
    if cfg.ndis > str.ndismax; cfg.ndis = str.ndismax; end
    cfg.mu = sign(rand-0.5);
    seq = builder(cfg);
    
    % visual cross
    txt = ('+');
    labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
    Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
    Screen('DrawingFinished',video.h);
    Screen('Flip',video.h);
    
    % run audio
    tstart = t+1.000+0.333*rand;
    tend = tstart+length(seq.x)/cfg.fsample;
    [seqbuf,seqpos] = CreateAudioBuffer(repmat(seq.x,[2,1]));
    PsychPortAudio('FillBuffer',audio.h,seqbuf);
    PsychPortAudio('SetLoop',audio.h,seqpos(1),seqpos(2));
    PsychPortAudio('Start',audio.h,1,tstart,0);
    
    % tapping option
    tapp = [];
    istapp = false;
    while true
        t = GetSecs;
        [~,~,but] = GetMouse;
        if t > tend
            break
        end
        if ~istapp && any(but)
            tapp = [tapp,t-tstart];
            istapp = true;
        end
        if istapp && ~any(but)
            istapp = false;
        end
        [~,~,key] = KbCheck(-1);
        if key(keyquit) > 0
            aborted = true;
            break
        end
    end
    if aborted; break; end
    
    PsychPortAudio('Stop',audio.h,1);
    txt = 'Go!';
    labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
    Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
    Screen('DrawingFinished',video.h);
    t0 = Screen('Flip',video.h);
    
    % response recording
    while true
        [~,t,key] = KbCheck(-1);
        if key(keyquit) > 0
            aborted = true;
            break
        end
        if any(key(keyresp) > 0)
            rt = t-t0;
            key = find(key(keyresp) > 0,1);
            resp = mapresp(key);
            iscor = sign(resp) == sign(cfg.mu);
            break
        end
    end
    if aborted; break; end
    Screen('Flip',video.h);
    
    if iscor; labelrgb = [0,1,0]; txt = 'correct';
    else;     labelrgb = [1,0,0]; txt = 'incorrect';
    end
    labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
    Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),labelrgb);
    Screen('DrawingFinished',video.h);
    t = Screen('Flip',video.h,t+0.250-0.5*video.ifi);
    Screen('Flip',video.h,t+0.500-0.5*video.ifi);
    
%     % staircase
    Y = SetStaircaseResponse(Y, 1/cfg.ndis, iscor);
    Y = RefreshStaircase(Y);
    
    % threshold = GetStaircaseThreshold(GetStaircaseResults(Y), cfg.avgstr);
    % save data
    save(['data/' filename], 'cfg', 'str', 'Y');
        
   if counter == str.nerror; mu = Y.x(Y.i); break; end
end
  
txt = (['Tr�s bien\n'...
    'Vous �tes d�sormais capable de r�aliser l''exp�rience de mani�re optimale.' ]); PsychVis
txt = (['Veuillez maintenant faire signe � l''exp�rimentateur, \n'...
    'afin qu''il initie la suite de l''exp�rience.' ]); PsychVis


    Priority(0);
    Screen('CloseAll');
    FlushEvents;
    ListenChar(0);
    ShowCursor;
    video = [];    
    PsychPortAudio('Close');
    audio = [];    
catch    
    if ~isempty(video)
        Priority(0);
        Screen('CloseAll');
        FlushEvents;
        ListenChar(0);
        ShowCursor;
    end    
    if ~isempty(audio)
        PsychPortAudio('Close');
    end    
    rethrow(lasterror);       
end