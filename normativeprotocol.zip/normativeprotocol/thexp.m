function thexp(filename, cfg)

% 3 TRIGGERS: soundstart & correct/error*RT
% % BIT = [1 2 4];
% % object  = io64; status  = io64(object); % should returns '0'
% % if status; display('io64 port not ready'); end
% % address = hex2dec('D010');

% Buttons
KbName('UnifyKeyNames');
keywait = KbName('space'); % press space to start bloc
keyquit = KbName('ESCAPE'); % press ESCAPE at response time to quit
keyresp = KbName({'DownArrow','UpArrow'}); % press DOWN for <f(REF) and UP for >f(REF)
mapresp = [-1,+1];
video     = [];
video.i   = max(Screen('Screens'));
video.res = Screen('Resolution',video.i);

% EXPERIMENT LOOP
PsychJavaTrouble;
try
    % initiate video
    HideCursor;
    FlushEvents;
    ListenChar(2);
%     Screen('Preference','SkipSyncTests',1); %!    
    Screen('Preference','VisualDebuglevel',3);
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask','General','UseFastOffscreenWindows');
    PsychImaging('AddTask','General','NormalizedHighresColorRange');
    video.h = PsychImaging('OpenWindow',video.i,0);
    [video.x,video.y] = Screen('WindowSize',video.h);
    video.ifi = Screen('GetFlipInterval',video.h,100,50e-6,10);
    Screen('BlendFunction',video.h,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    Priority(MaxPriority(video.h));
    Screen('ColorRange',video.h,1);
    Screen('TextFont',video.h,'Arial');
    Screen('TextSize',video.h,round(0.5*cfg.ppx));
    Screen('FillRect',video.h,0.5); % background luminance
    
    % initiate sound
    InitializePsychSound(1);
    devices = PsychPortAudio('GetDevices');
    for i0 = 1:length(devices)
        if devices(i0).NrInputChannels == 0 && devices(i0).NrOutputChannels == 2
            break
        end
    end
    audio = [];
    audio.i = devices(i0).DeviceIndex;
    audio.freq = devices(i0).DefaultSampleRate;
    audio.h = PsychPortAudio('Open',audio.i,1,1,audio.freq,2);
    PsychPortAudio('RunMode',audio.h,1);

    txt = (['Vous allez maintenant commencer la v�ritable exp�rience \n'...
        'qui se d�roulera en blocs de quelques minutes chacun. '...
        'A chaque bloc correspondra un rythme (+ ou - rapide). '...
        'Ceux-ci seront donc plus ou moins longs mais pr�senteront un nombre '...
        'd''essais identique']);PsychVis
%     txt = (['L''exp�rience comportera deux conditions: \n' ...
%         'Dans la condition "Listen" vous ne devrez bouger '...
%         'aucune partie de votre corps, seulement imaginer le rythme dans votre t�te '...
%         'pour d�tecter si le son deviant tombe EN rythme ou HORS rythme.\n' ...
%         'Dans la condition "Tracking" vous devrez battre en mesure le rythme,'...
%         'avec l''index de votre main pr�f�r�e. \n' ...
%         'Commencez � taper le rythme pendant la pr�sentation des sons de r�f�rence.\n'...
%         'Ceci vous aidera � bien vous synchroniser avec le rythme.']); PsychVis
%     txt = (['Information importante: vous NE DEVEZ PAS battre le rythme en mesure. '...
%         ' Vous ne devez pas bouger, seulement imaginer le rythme dans votre t�te '...
%         'pour d�tecter si le son deviant final tombe EN rythme ou HORS du rythme.']); PsychVis
    txt = (['R�pondez "Le son d�viant final est tomb� EN rythme" en pressant la fl�che du haut sur le clavier,\n'...
        'et "Le son d�viant final est tomb� HORS du rythme" en pressant la fl�che du bas sur le clavier.']); PsychVis
    txt = (['Fixez la croix au milieu de l''�cran lors de la pr�sentation des sons. '...
        'Cela vous permettra de vous concentrer sur la s�quence.']); PsychVis    
    txt = (['Concentrez-vous bien ! \n'...
        'Bonne chance !']) ; PsychVis
    
        if cfg.cond == 1 % Tracking
    txt = (['Surtout n''oubliez pas \n' ...          
        'de battre en mesure le rythme de r�f�rence avec l''index de votre main gauche sur le boitier pr�vu'...
        '� cet effet.\n' ... 
    'Commencez � taper le rythme pendant la pr�sentation des sons de r�f�rence.']); PsychVis        
elseif cfg.cond == 2 % Listen
    txt = (['Surtout n''oubliez pas : NE BOUGEZ PAS !\n'...
        'Il est tr�s important de ne pas battre le rythme ; de ne bouger aucune partie de votre corps. \n'...
        'Suivez seulement le rythme dans votre t�te.']); PsychVis
        end
        
    txt = ('Pr�t(e)?'); PsychVis
    
% initialize output variable
X    = [];
aborted = false;

% randomize blocs (fn nbeat)
shuffle = @(v)v(randperm(numel(v))); % function
x = [shuffle(1:cfg.nbloc/2), shuffle(1:cfg.nbloc/2)]; %!
ibeat = repmat(1:cfg.nbeat, 1, cfg.nbloc/cfg.nbeat); ibeat = ibeat(x);
% icond = repmat([ones(1,cfg.nbeat), 2*ones(1,cfg.nbeat)], 1,2); icond = icond(x);
icond = repmat(2, 1, cfg.nbloc); % listen only
clear shuffle x

for ibloc = 1:cfg.nbloc
    cfg.cond = icond(ibloc);
    cfg.beat = cfg.fbeat(ibeat(ibloc));
%     txt = sprintf(['Bloc %d/%d: Condition %s.\n'...
%         'Vitesse %d/%d.'], ...
%         ibloc, cfg.nbloc, cfg.condtype{cfg.cond}, ibeat, length(cfg.fbeat)); PsychVis
    txt = sprintf('Bloc %d/%d - Vitesse %d/%d', ...
        ibloc, cfg.nbloc, ibeat(ibloc), length(cfg.fbeat)); PsychVis

    % create sequence of responses (up|down)
    while true
        xrand = randperm(cfg.ntrial);
        ipitch = [+1*ones(1,cfg.ntrial/2) -1*ones(1,cfg.ntrial/2)];
        ipitch = ipitch(xrand);
        if ~HasConsecutiveValues(ipitch, 4); break; end
    end
    X.pitch(ibloc,:) = ipitch; % on|off beat   
    clear ipitch xrand
    
    for itrial = 1:cfg.ntrial
        % cfg.ndis % difficulty
        cfg.mu = X.pitch(ibloc,itrial);
        seq    = builder(cfg);
        
        X.seq(ibloc,itrial)      = rmfield(seq,'x');
        X.cond(ibloc,itrial)     = cfg.cond;
        X.beat(ibloc,itrial)     = cfg.beat;
        X.mu(ibloc,itrial)       = cfg.mu;
        X.tapp(ibloc,itrial,:)   = NaN(1,20);
        X.resp(ibloc,itrial)     = NaN;
        X.rt(ibloc,itrial)       = NaN;
        X.iscor(ibloc,itrial)    = NaN;
        X.trialons(ibloc,itrial) = NaN;
        X.respons(ibloc,itrial)  = NaN;
        
        % visual cross
        txt = ('+');
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
        Screen('DrawingFinished',video.h);
        Screen('Flip',video.h);
        
        % run audio
        tstart = t+1.000+0.333*rand;
        tend = tstart+length(seq.x)/cfg.fsample;
        [seqbuf,seqpos] = CreateAudioBuffer(repmat(seq.x,[2,1]));
        PsychPortAudio('FillBuffer',audio.h,seqbuf);
        PsychPortAudio('SetLoop',audio.h,seqpos(1),seqpos(2));
        PsychPortAudio('Start',audio.h,1,tstart,0);
        
        % audio trigger
        while true
            t = GetSecs;
            if t > tstart
                % % io64(object,address,BIT(1); % 1
                % % WaitSecs(0.001); io64(object,address,0);
                X.trialons(ibloc,itrial) = tstart;
                break
            end
        end
        
        % tapping option
        tapp = [];
        istapp = false;
        while true
            t = GetSecs;
            % [~,~,but] = GetMouse;
            [~,~,but] = KbCheck(-1);
            if t > tend
                break
            end
            if ~istapp && any(but)
                tapp = [tapp,t-tstart];
                istapp = true;
            end
            if istapp && ~any(but)
                istapp = false;
            end
            [~,~,key] = KbCheck(-1);
            if key(keyquit) > 0
                aborted = true;
                break
            end
        end
        if aborted; break; end
        
        PsychPortAudio('Stop',audio.h,1);
        txt = 'Go!';
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
        Screen('DrawingFinished',video.h);
        t0 = Screen('Flip',video.h);
        
        % response recording
        while true
            [~,t,key] = KbCheck(-1);
            if key(keyquit) > 0
                aborted = true;
                break
            end
            if any(key(keyresp) > 0)
                rt = t-t0;
                key = find(key(keyresp) > 0,1);
                resp = mapresp(key);
                iscor = sign(resp) == X.pitch(ibloc,itrial);
                % % io64(object,address,BIT(3-iscor)); % 2correct|3error
                % % WaitSecs(0.001); io64(object,address,0);
                X.respons(ibloc,itrial) = t;
                break
            end
        end
        if aborted; break; end
        Screen('Flip',video.h);
        
        if iscor
            txt = 'vrai'; labelrgb = [0,1,0];
        else
            txt = 'faux';   labelrgb = [1,0,0];
        end
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),labelrgb);
        Screen('DrawingFinished',video.h);
        t = Screen('Flip',video.h,t+0.250-0.5*video.ifi);
        Screen('Flip',video.h,t+0.500-0.5*video.ifi);
        
        if cfg.cond == 1 && length(tapp) < cfg.ntar
            txt = 'S''il vous plait, veuillez bien suivre le rythme en tapant';
            labelrgb = [1,0,0];
        end
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),labelrgb);
        Screen('DrawingFinished',video.h);
        t = Screen('Flip',video.h,t+0.250-0.5*video.ifi);
        Screen('Flip',video.h,t+1.000-0.5*video.ifi);
        
        % results
        if ~isempty(tapp)
            X.tapp(ibloc,itrial,1:length(tapp)) = tapp;
        end
        X.resp(ibloc,itrial)  = resp;
        X.rt(ibloc,itrial)    = rt;
        X.iscor(ibloc,itrial) = iscor;
        
        % save data
        save(['data/' filename], 'cfg', 'X');
    end
    if aborted; break; end    
    txt = sprintf('Votre score est de : %02d/%02d',nnz(X.iscor(ibloc,:)),cfg.ntrial); PsychVis
    
    % pause after every 4 blocs
    if mod(ibloc,cfg.nbloc/4) == 0 && ibloc ~= cfg.nbloc
        txt = ('Veuillez, je vous prie, faire une petite pause (30sec). (puis pressez la barre d''espace pour continuer)'); PsychVis
    end
end

    txt = sprintf(['Bravo! \n'...
        'Vous �tes arriv�(e) au bout de l''exp�rience. \n'...
        'Merci de votre participation. \n'...
        'Veuillez faire signe � l''exp�rimentateur.']);PsychVis
        
    Priority(0);
    Screen('CloseAll');
    FlushEvents;
    ListenChar(0);
    ShowCursor;
    video = [];
    PsychPortAudio('Close');
    audio = [];
catch
    if ~isempty(video)
        Priority(0);
        Screen('CloseAll');
        FlushEvents;
        ListenChar(0);
        ShowCursor;
    end
    if ~isempty(audio)
        PsychPortAudio('Close');
    end
    rethrow(lasterror);   
end
