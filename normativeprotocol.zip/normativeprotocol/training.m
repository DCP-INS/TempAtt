function training(cfg, trn)

% Buttons
KbName('UnifyKeyNames');
keywait = KbName('space'); % press space to start bloc
keyquit = KbName('ESCAPE'); % press ESCAPE at response time to quit
keyresp = KbName({'DownArrow','UpArrow'}); % press DOWN for <f(REF) and UP for >f(REF)
mapresp = [-1,+1];
video     = [];
video.i   = max(Screen('Screens'));
video.res = Screen('Resolution',video.i);

% EXPERIMENT LOOP
PsychJavaTrouble;
try
    % initiate video
    HideCursor;
    FlushEvents;
    ListenChar(2);
    % Screen('Preference','SkipSyncTests',1); %!
    Screen('Preference','VisualDebuglevel',3);
    PsychImaging('PrepareConfiguration');
    PsychImaging('AddTask','General','UseFastOffscreenWindows');
    PsychImaging('AddTask','General','NormalizedHighresColorRange');
    video.h = PsychImaging('OpenWindow',video.i,0);
    [video.x,video.y] = Screen('WindowSize',video.h);
    video.ifi = Screen('GetFlipInterval',video.h,100,50e-6,10);
    Screen('BlendFunction',video.h,GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    Priority(MaxPriority(video.h));
    Screen('ColorRange',video.h,1);
    Screen('TextFont',video.h,'Helvetica');
    Screen('TextSize',video.h,round(0.5*cfg.ppx));
    Screen('FillRect',video.h,0.5); % background luminance
    
    % initiate sound
    InitializePsychSound(1);
    devices = PsychPortAudio('GetDevices');
    for i0 = 1:length(devices)
        if devices(i0).NrInputChannels == 0 && devices(i0).NrOutputChannels == 2
            break
        end
    end
    audio = [];
    audio.i = devices(i0).DeviceIndex;
    audio.freq = devices(i0).DefaultSampleRate;
    audio.h = PsychPortAudio('Open',audio.i,1,1,audio.freq,2);
    PsychPortAudio('RunMode',audio.h,1);
    
% LOOP
for i0 = 1:length(trn.ndis0)
    if i0 == 1        
        txt = ('Cher(e) participant(e),\n (appuyez sur la barre d''espace pour faire d�filer le texte)'); PsychVis        
        txt = (['Vous allez �couter de courtes s�quences rythmiques. \n'...
            'A la fin de la s�quence un son deviant (plus aigu) apparaitra. \n'...
            'On vous demandera d''estimer si ce son tombe SUR le rythme ou HORS du rythme.']); PsychVis        
        txt = (['Pour r�pondre correctement il s''agit de bien suivre \n'...
            'le rythme pendant toute la s�quence.']); PsychVis
        txt = (['Pour r�pondre, pressez sur le clavier \n'...
            'la fl�che du haut si le son d�viant final tombe EN rythme; \n'...
            'et la fl�che du bas si celui-ci tombe HORS du rythme.']); PsychVis
        txt = (['Veuillez fixer la croix au milieu de l''�cran lors de la pr�sentation des sons. '...
            'Cela permettra de vous concentrer sur la s�quence.']); PsychVis
        txt = ('Pr�t(e) pour un petit exemple?'); PsychVis
    end    
    if i0 == 2
        txt = ('Tr�s bien'); PsychVis
        txt = (['Maintenant chaque s�quence va d�buter par 3 sons de r�f�rence indiquant le rythme, \n'...
            'suivis d''une alternance de sons en rythme et hors du rythme.']); PsychVis        
         txt = (['Pour r�pondre correctement il faut bien faire attention au '...
            'rythme donn� par les sons de r�f�rence et de continuer � suivre \n'...
            'celui-ci pendant toute la s�quence, en ignorant les sons distracteurs (hors rythme).']); PsychVis
    end
    if i0 == 3
        txt = ('Tr�s bien'); PsychVis
        txt = (['Nous allons maintenant augmenter progressivement le nombre \n' ...
            'de sons hors rythme pr�sent�s dans chaque s�quence.' ]); PsychVis                
    end
    if i0 == 5
        txt = ('Parfait'); PsychVis
        txt = (['Pour terminer nous allons changer le rythme des s�quences: \n' ...
            'celui-ci sera d''abord tr�s lent, puis de plus en plus rapide.\n' ...
            'La t�che reste la m�me.' ]); PsychVis    
    end

    aborted = false;
    counter = 0;  
    while true        
        % extra parameters
        cfg.mu    = sign(rand-0.5); %+1|-1
        cfg.ndis  = trn.ndis0(i0);
        cfg.beat  = trn.fbeat(i0);
        seq       = builder(cfg);
        % figure; plot(seq.x); sound(seq.x,cfg.fsample) % clear sound
        
        % visual cross
        txt = ('+');
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
        Screen('DrawingFinished',video.h);
        Screen('Flip',video.h);
        
        % run audio
        tstart = t+1.000+0.333*rand;
        tend = tstart+length(seq.x)/cfg.fsample;
        [seqbuf,seqpos] = CreateAudioBuffer(repmat(seq.x,[2,1]));
        PsychPortAudio('FillBuffer',audio.h,seqbuf);
        PsychPortAudio('SetLoop',audio.h,seqpos(1),seqpos(2));
        PsychPortAudio('Start',audio.h,1,tstart,0);
        
        % tapping option
        tapp = [];
        istapp = false;
        while true
            t = GetSecs;
            [~,~,but] = GetMouse;
            if t > tend
                break
            end
            if ~istapp && any(but)
                tapp = [tapp,t-tstart];
                istapp = true;
            end
            if istapp && ~any(but)
                istapp = false;
            end
            [~,~,key] = KbCheck(-1);
            if key(keyquit) > 0
                aborted = true;
                break
            end
        end
        if aborted; break; end
        
        PsychPortAudio('Stop',audio.h,1);
        txt = 'Go!';
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),1);
        Screen('DrawingFinished',video.h);
        t0 = Screen('Flip',video.h);
        
        % response recording
        while true
            [~,t,key] = KbCheck(-1);
            if key(keyquit) > 0
                aborted = true;
                break
            end
            if any(key(keyresp) > 0)
                rt = t-t0;
                key = find(key(keyresp) > 0,1);
                resp = mapresp(key);
                iscor = sign(resp) == sign(cfg.mu);
                break
            end
        end
        if aborted; break; end
        Screen('Flip',video.h);
        
        if iscor
            counter = counter+1; labelrgb = [0,1,0];
            txt = sprintf('correct (%g/%g)',counter,trn.maxresp(i0));
        else
            counter = 0; labelrgb = [1,0,0]; txt = 'faux';
        end
        labelrec = CenterRectOnPoint(Screen('TextBounds',video.h,txt),video.x/2,video.y/2);
        Screen('DrawText',video.h,txt,labelrec(1),labelrec(2),labelrgb);
        Screen('DrawingFinished',video.h);
        t = Screen('Flip',video.h,t+0.250-0.5*video.ifi);
        Screen('Flip',video.h,t+0.500-0.5*video.ifi);
        
        if counter == trn.maxresp(i0)
            break
        end
    end
    if aborted; break; end
end
txt = (['Bravo!\n Vous �tes arriv� au bout de l''entra�nement. Nous allons d�sormais d�finir '...
        'votre seuil perceptif afin de pouvoir r�aliser au mieux l''exp�rience. Un programme va '...
        'se lancer, merci d''attendre un instant les prochaines instructions.']); PsychVis
    
    Priority(0);
    Screen('CloseAll');
    FlushEvents;
    ListenChar(0);
    ShowCursor;
    video = [];
    PsychPortAudio('Close');
    audio = [];
catch
    if ~isempty(video)
        Priority(0);
        Screen('CloseAll');
        FlushEvents;
        ListenChar(0);
        ShowCursor;
    end
    if ~isempty(audio)
        PsychPortAudio('Close');
    end
    rethrow(lasterror);
end